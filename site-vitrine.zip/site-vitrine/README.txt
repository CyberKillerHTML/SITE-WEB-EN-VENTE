Merci pour votre achat !

Voici votre site vitrine.
Pour le mettre en ligne :
1. Connectez-vous à votre hébergement (OVH, IONOS, o2switch…)
2. Ouvrez le gestionnaire de fichiers
3. Glissez-déposez tous les fichiers du dossier dans /www/
4. Votre site sera visible immédiatement

Si vous souhaitez des modifications, contactez-moi.
